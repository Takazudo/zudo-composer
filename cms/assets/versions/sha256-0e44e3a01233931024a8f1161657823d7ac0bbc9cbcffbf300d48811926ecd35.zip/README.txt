This tiny archive is bundled with the hosted Assets demonstration.
